
#Exercício B1 - Número Positivo ou Negativo

num = int(input("Insere um numero: "))
if num >= 0:
    print(f'O numero {num} é positivo')
else:
    print(f'O numero {num} é negativo')

#Exercício B2 - Maior de Idade

idade = int(input("Insere a tua idade: "))
if idade >= 18:
    print("És maior de idade")
else:
    print("És menor de idade")

#Exercício B3 - Número Par ou Ímpar

num_2 = int(input("Insere um numero: "))
if num % 2 == 0:
    print(f'O numero {num_2} é par')
else:
    print(f'O numero {num_2} é impar')


#Exercício B4 - Comparação de Dois Números

opA = int(input("Insere o primeiro numero: "))
opB = int(input("Insere o segundo numero: "))
if opA > opB:
    print(f'O numero {opA} é o maior numero')
else:
    print(f'O numero {opB} é o maior numero')


#Exercício B5 - Password Simples

password = input("Insere uma password: ")
if password == "python":
    print("Acesso Permitido")
else:
    print("Acesso Negado")

#Exercício I1 - Classificação de Nota
nota = int(input("Indique uma nota: "))
if nota < 10:
    print("Estas reprovado")
elif (nota >= 10 and nota <= 14):
    print("Suficiente")
elif (nota >14 and nota <= 18):
    print("Bom") 
else:
    print("Excelente")


#Exercício I2 - Classificação de Idade
idade_2 = int(input("Indique a sua idade: "))
if idade_2 < 13:
    print("Criança")
elif (idade_2 >= 13 and idade_2 <= 17):
    print("Jovem")
elif (idade_2 >=18 and idade_2 <= 64):
    print("Adulto") 
else:
    print("Senior")


#Exercício I3 - Múltiplo de 3 e 5
num_3 = int(input("Digite um número: "))

if num_3 % 3 == 0 and num_3 % 5 == 0:
    print("Múltiplo de 3 e 5")
elif num_3 % 3 == 0:
    print("Múltiplo de 3")
elif num_3 % 5 == 0:
    print("Múltiplo de 5")
else:
    print("Nenhum")

#Exercício I4 - Login com Utilizador e Password
user_correto = input("Insere o user: ")
passe_correta = input("Insere a pass: ")
if user_correto != "admin":
    print("User incorreto")
if passe_correta != "1234":
    print("passe incorreta")
if user_correto != "admin" and passe_correta != "1234":
    print("User e passe incorretos")

#Exercício I5 - Número dentro de intervalo
num_4 = int(input("Insere um valor: "))
if num_4 >= 10 and num_4 <= 20:
    print(f'O numero {num_4} está entre o intervalo de 10 e 20')
else:
    print(f'O numero {num_4} nao está entre o intervalo de 10 e 20')

#Exercício A1 - Sistema Multibanco Simples
saldo_inicial = 1000
valor_a_levantar = int(input("Insere o valor a levantar: "))
if valor_a_levantar < saldo_inicial:
    print("Autorizado")
else:
    print("Saldo insuficiente")

op1 = int(input("Insere o primeiro numero: "))
op2 = int(input("Insere o segundo numero: "))
op3 = int(input("Insere o terceiro  numero: "))
op4 = int(input("Insere o quarto  numero: "))
if op1 >= op2 and op1 >= op3 and op1 >= op4:
    print(f'O {op1} é o maior numero.')
elif op2 >= op1 and op2 >= op3 and op2 >= op4:
   print(f'O {op2} é o maior numero.')
elif op3 >= op1 and op3 >= op2 and op3 >= op4:
   print(f'O {op3} é o maior numero')
elif op4 >= op1 and op4 >= op2 and op4 >= op3:
    print(f'O {op4} é o maior numero') 
else:
    ("Todos os numeros sao iguais")
    
#Exercício A3 - Classificação de IMC (Simplificado)

peso = float(input("Digite o peso: "))
altura = float(input("Digite a altura: "))

imc = peso / (altura * altura)

if imc < 18.5:
    print("Baixo peso")
elif imc <= 24.9:
    print("Normal")
elif imc <= 29.9:
    print("Excesso de peso")
else:
    print("Obesidade")

print(imc)

#Exercício A4 - Sistema de Desconto
valor_da_compra = int(input("Insere o valor da compra: "))
if valor_da_compra >= 100:
    desconto = valor_da_compra * 0.1
    valor_final = valor_da_compra - desconto
    print(f'O desconto é de {desconto} e o valor a pagar é de {valor_final}')
elif valor_da_compra >= 50:
    desconto = valor_da_compra * 0.05
    valor_final = valor_da_compra - desconto
    print(f'O desconto é de {desconto} e o valor a pagar é de {valor_final}')
else:
    print("Sem desconto")

    
#Exercício A5 - Verificação de Ano Bissexto (Simplificado)
ano_atual = int(input("Insere o ano atual: "))
if ano_atual % 4 == 0:
    print("Ano bissexto")
else:
    print("Ano normal")
