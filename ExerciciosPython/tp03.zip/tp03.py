nota = int(input("Insere a nota: "))
print(nota >= 10)

opA = int(input("Insere o valor: "))
print(opA %2)

user_correto = input("Insere o user: ")
passe_correta = input("Insere a pass: ")
print(user_correto == "admin" and passe_correta == "1234") 

