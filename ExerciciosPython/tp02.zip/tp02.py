opA = int(input("Indique o primeiro valor: "))
opB = int(input("Indique o segundo valor: "))

soma = opA + opB


print(f'O resultado da soma entre {opA} e {opB} é {soma}')



c = float(input("Temperatua em celsius: "))
f = (c * 9/5) + 32
print("Fahrenheit", f)


opA = float(input("Insere o primeiro numero: "))
opB = float(input("Insere o segundo numero numero: "))
soma = opA + opB
subtracao = opA - opB
multiplicacao = opA * opB
divisao = float(opA) / float(opB)
print(f'o resultado da soma é: {soma}')
print(f'o resultado da subtracao é: {subtracao}')
print(f'o resultado da multiplicacao é: {multiplicacao}')
print(f'o resultado da divisao é: {divisao}')