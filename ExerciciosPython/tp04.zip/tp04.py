#exercicio 1 
saldo = 100
valor_a_levantar = int(input("Insere o valor a levantar: "))
saldo_restante = saldo - valor_a_levantar

if saldo >= valor_a_levantar:
    print(f'Levantou {valor_a_levantar} euros.')
else:
    print("Nao tens permissao para levantar esse valor")
print(f'Ficas com {saldo_restante} euros.')


#Exercicio 2 
idade = int(input("Insere a tua idade: "))

if idade < 13: 
    print("Criança")
elif idade > 13 and idade < 17:
    print("Jovem")
elif idade > 18 and idade < 64:
    print("Adulto")
else:
    print("Senior")

opA = int(input("Insere o primeiro numero: "))
opB = int(input("Insere o segundo numero: "))
opC = int(input("Insere o terceiro  numero: "))

if opA >= opB and opA >= opC:
    print(f'O {opA} é o maior numero.')
elif opB >= opA and opB >= opC:
  print(f'O {opB} é o maior numero.')
elif opC >= opA and opC >= opB:
   print(f'{opC}')
else:
    ("Todos os numeros sao iguais")

#mini deafio final 
valor_da_compra = int(input("Insere o valor da compra: "))
desconto = 0
if valor_da_compra >= 100:
    desconto = valor_da_compra * 0.1
    valor_final = valor_da_compra - desconto
    print(f'O desconto é de {desconto} e o valor a pagar é de {valor_final}')
elif valor_da_compra >= 50: 
    desconto = valor_da_compra * 0.05
    valor_final = valor_da_compra - desconto
    print(f'O desconto é de {desconto} e o valor a pagar é de {valor_final}')
    

    

