
#Exercício B1 - Contagem Simples (while) 
#Criar um programa que:
#Mostre números de 1 a 10 usando while.
i = 1
while i < 11:
    print(i)
    i += 1

# Exercício B2 - Contagem Decrescente (while)
# Criar um programa que:
# Mostre números de 10 até 1.

i = 10
while i > 1:
    print(i)
    i -= 1

# Exercício B3 - Contagem com for
# Criar um programa que:
# Mostre números de 1 a 20 usando for.

for i in range (1,21):
    print(i)
    i += 1

# Exercício B4 - Números Pares
# Criar um programa que:
# Mostre apenas números pares entre 1 e 20.

for i in range (0,21,2):
    print(i)
    i += 1

# Exercício I1 - Soma de 1 a 100
# Criar programa que:
# Calcule a soma dos números de 1 a 100.
soma = 0

for i in range(1,101):
    soma += i
    print(f"a somar {i} Soma atual: {soma}") 
          
print(f"Resultado final: {soma}")

# Exercício I2 - Tabuada
# Criar programa que:
# Peça um número
# Continue a pedir enquanto o número for positivo
# Só termina quando o número for negativo

num = int(input("Insere um numero: "))
while num > 0:
    print(num)
    num = int(input("Insere um numero: "))
else:
    print("O programa foi interrompido")

# Exercício I3 - Contador de Pares
# Criar programa que:
# Conte quantos números pares existem entre 1 e 50.

i = 0

for numero in range(0, 51, 2):
    print(numero)
    i += 1

print(f'Tem {i} numeros pares')


# Exercício A1 - Soma Personalizada
# Criar programa que:
# Pergunte quantos números o utilizador quer inserir
# Peça esses números
# Mostre a soma total

quantidade = int(input("Quantos números quer inserir? "))
soma = 0

for i in range(quantidade):
    numero = int(input("Digite um número: "))
    soma += numero

print("A soma total é:", soma)



# Exercício A2 - Menu Repetitivo
# Criar programa com menu:
# 1 – Mostrar números de 1 a 10
# 2 – Mostrar números pares até 20
# 0 – Sair

# O menu deve repetir até o utilizador escolher 0.

opcao = -1

while opcao != 0:
    print("MENU")
    print("1 - Mostrar números de 1 a 10")
    print("2 - Mostrar números pares até 20")
    print("0 - Sair")

    opcao = int(input("Escolha uma opção: "))

    if opcao == 1:
        for i in range(1, 11):
            print(i)

    elif opcao == 2:
        for i in range(2, 21, 2):
            print(i)

    elif opcao == 0:
        print("Programa terminado")

    else:
        print("Opção inválida")


# Exercício A3 - Fatorial
# Criar programa que:
# Peça um número
# Calcule o fatorial desse número

# Exemplo:
# 5! = 5 × 4 × 3 × 2 × 1

numero = int(input("Digite um número: "))
fatorial = 1

for i in range(1, numero + 1):
    fatorial *= i

print(f"O fatorial de {numero} é {fatorial}")



