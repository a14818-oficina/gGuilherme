# Exercicio 1
print("Guilherme")
print("GPSI")
print("OFICINA")


# Exercicio 2
nome = input("Qual é o teu nome? ")
idade = input ("Qual é a tua idade? ")
print(f'Olá {nome}, tens {idade} anos')


# Desafio
nome = input("Qual é o teu nome? ")
data_nascimento = int(input("Qual é o teu ano de nascimento? "))
ano_atual = 2026
idade = ano_atual - data_nascimento
print(f'{nome}, tens aproximadamente {idade}.')
